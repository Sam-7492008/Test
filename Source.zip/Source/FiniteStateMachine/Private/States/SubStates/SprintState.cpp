// Fill out your copyright notice in the Description page of Project Settings.


#include "States/SubStates/SprintState.h"

#include "StateContext.h"
#include "StateData.h"
#include "StateMachineOwner.h"

void USprintState::Update(const FStateContext& StateContext)
{
	if (!StateContext.Owner) return;
	
	StateContext.Owner->StartMovement(StateData->SprintSpeed);
}
